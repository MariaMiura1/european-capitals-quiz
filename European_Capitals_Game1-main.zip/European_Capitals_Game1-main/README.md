<<<<<<< HEAD
# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Babel](https://babeljs.io/) (or [oxc](https://oxc.rs) when used in [rolldown-vite](https://vite.dev/guide/rolldown)) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

## React Compiler

The React Compiler is not enabled on this template because of its impact on dev & build performances. To add it, see [this documentation](https://react.dev/learn/react-compiler/installation).

## Expanding the ESLint configuration

If you are developing a production application, we recommend using TypeScript with type-aware lint rules enabled. Check out the [TS template](https://github.com/vitejs/vite/tree/main/packages/create-vite/template-react-ts) for information on how to integrate TypeScript and [`typescript-eslint`](https://typescript-eslint.io) in your project.
=======
# European Capitals Game

A simple educational game to learn the capitals of Europe.

## Project goal

The goal of this project is to create a small interactive quiz that helps users learn European capitals through repetition and gameplay.

## Features

- Multiple choice questions
- Score tracking
- Lives system
- Random questions

## Technologies

- React
- JavaScript
- HTML
- CSS

## Future improvements

- Map mode
- Difficulty levels
- Timer mode
- Sound effects

## Author

Maria Miura Pareja
>>>>>>> dbf55e158ed9da3b8db4e7a55ffa7f765f6d640f
