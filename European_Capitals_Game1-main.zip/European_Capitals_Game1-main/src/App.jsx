import { useMemo, useState } from "react";
import EuropeMap from "./EuropeMap";

export default function App() {
  const capitals = useMemo(
    () => [
      { country: "España", countryMap: "Spain", capital: "Madrid" },
      { country: "Francia", countryMap: "France", capital: "París" },
      { country: "Alemania", countryMap: "Germany", capital: "Berlín" },
      { country: "Italia", countryMap: "Italy", capital: "Roma" },
      { country: "Portugal", countryMap: "Portugal", capital: "Lisboa" },
      { country: "Países Bajos", countryMap: "Netherlands", capital: "Ámsterdam" },
      { country: "Bélgica", countryMap: "Belgium", capital: "Bruselas" },
      { country: "Austria", countryMap: "Austria", capital: "Viena" },
      { country: "Grecia", countryMap: "Greece", capital: "Atenas" },
      { country: "Irlanda", countryMap: "Ireland", capital: "Dublín" },
      { country: "Polonia", countryMap: "Poland", capital: "Varsovia" },
      { country: "Suecia", countryMap: "Sweden", capital: "Estocolmo" },
      { country: "Noruega", countryMap: "Norway", capital: "Oslo" },
      { country: "Finlandia", countryMap: "Finland", capital: "Helsinki" },
      { country: "Dinamarca", countryMap: "Denmark", capital: "Copenhague" },
      { country: "Suiza", countryMap: "Switzerland", capital: "Berna" },
      { country: "Hungría", countryMap: "Hungary", capital: "Budapest" },
      { country: "República Checa", countryMap: "Czech Republic", capital: "Praga" },
      { country: "Rumanía", countryMap: "Romania", capital: "Bucarest" },
      { country: "Bulgaria", countryMap: "Bulgaria", capital: "Sofía" },
      { country: "Serbia", countryMap: "Serbia", capital: "Belgrado" },
      { country: "Croacia", countryMap: "Croatia", capital: "Zagreb" },
      { country: "Bosnia y Herzegovina", countryMap: "Bosnia and Herzegovina", capital: "Sarajevo" },
      { country: "Eslovenia", countryMap: "Slovenia", capital: "Liubliana" },
      { country: "Eslovaquia", countryMap: "Slovakia", capital: "Bratislava" },
      { country: "Estonia", countryMap: "Estonia", capital: "Tallín" },
      { country: "Letonia", countryMap: "Latvia", capital: "Riga" },
      { country: "Lituania", countryMap: "Lithuania", capital: "Vilna" },
      { country: "Islandia", countryMap: "Iceland", capital: "Reikiavik" },
      { country: "Ucrania", countryMap: "Ukraine", capital: "Kiev" },
      { country: "Bielorrusia", countryMap: "Belarus", capital: "Minsk" },
      { country: "Moldavia", countryMap: "Moldova", capital: "Chisináu" },
      { country: "Albania", countryMap: "Albania", capital: "Tirana" },
      { country: "Macedonia del Norte", countryMap: "North Macedonia", capital: "Skopie" },
      { country: "Montenegro", countryMap: "Montenegro", capital: "Podgorica" },
      { country: "Kosovo", countryMap: "Kosovo", capital: "Pristina" },
      { country: "Luxemburgo", countryMap: "Luxembourg", capital: "Luxemburgo" },
      { country: "Liechtenstein", countryMap: "Liechtenstein", capital: "Vaduz" },
      { country: "Andorra", countryMap: "Andorra", capital: "Andorra la Vieja" },
      { country: "Mónaco", countryMap: "Monaco", capital: "Mónaco" },
      { country: "San Marino", countryMap: "San Marino", capital: "San Marino" },
      { country: "Malta", countryMap: "Malta", capital: "La Valeta" },
      { country: "Chipre", countryMap: "Cyprus", capital: "Nicosia" },
      { country: "Turquía", countryMap: "Turkey", capital: "Ankara" }
    ],
    []
  );

  const [currentIndex, setCurrentIndex] = useState(() =>
    Math.floor(Math.random() * capitals.length)
  );
  const [score, setScore] = useState(0);
  const [message, setMessage] = useState("");
  const [textAnswer, setTextAnswer] = useState("");
  const [mistakesByCountry, setMistakesByCountry] = useState({});
  const [lastIndex, setLastIndex] = useState(null);

  const current = capitals[currentIndex];

  const normalize = (text) =>
    text
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim();

  const useTextMode = score >= 40;

  const getNextWeightedIndex = (mistakes, previousIndex) => {
    const weightedIndexes = capitals.flatMap((item, index) => {
      const mistakesCount = mistakes[item.country] || 0;
      const weight = 1 + mistakesCount * 5;
      return Array(weight).fill(index);
    });

    let nextIndex =
      weightedIndexes[Math.floor(Math.random() * weightedIndexes.length)];

    if (capitals.length > 1 && nextIndex === previousIndex) {
      let tries = 0;
      while (nextIndex === previousIndex && tries < 10) {
        nextIndex =
          weightedIndexes[Math.floor(Math.random() * weightedIndexes.length)];
        tries += 1;
      }
    }

    return nextIndex;
  };

  const shuffledOptions = useMemo(() => {
    if (!current) return [];

    const wrongOptions = capitals
      .filter((item) => item.capital !== current.capital)
      .sort(() => Math.random() - 0.5)
      .slice(0, 3)
      .map((item) => item.capital);

    return [current.capital, ...wrongOptions].sort(() => Math.random() - 0.5);
  }, [current, capitals]);

  const goToNextQuestion = (updatedMistakes) => {
    setTimeout(() => {
      const nextIndex = getNextWeightedIndex(updatedMistakes, currentIndex);
      setLastIndex(currentIndex);
      setCurrentIndex(nextIndex);
      setMessage("");
      setTextAnswer("");
    }, 1200);
  };

  const handleCorrectAnswer = () => {
    setScore((prev) => prev + 1);
    setMessage("✅ ¡¡MUY BIEN!!");
    goToNextQuestion(mistakesByCountry);
  };

  const handleWrongAnswer = () => {
    const updatedMistakes = {
      ...mistakesByCountry,
      [current.country]: (mistakesByCountry[current.country] || 0) + 1
    };

    setMistakesByCountry(updatedMistakes);
    setMessage(`❌ Incorrecto. La respuesta correcta es ${current.capital}`);
    goToNextQuestion(updatedMistakes);
  };

  const handleOptionClick = (selectedCapital) => {
    if (selectedCapital === current.capital) {
      handleCorrectAnswer();
    } else {
      handleWrongAnswer();
    }
  };

  const handleTextSubmit = () => {
    if (normalize(textAnswer) === normalize(current.capital)) {
      handleCorrectAnswer();
    } else {
      handleWrongAnswer();
    }
  };

  return (
    <div
      style={{
        fontFamily: "Arial, sans-serif",
        textAlign: "center",
        padding: "20px",
        color: "#111827",
        background: "linear-gradient(to bottom, #eff6ff, #ffffff)",
        minHeight: "100vh"
      }}
    >
      <h1 style={{ marginBottom: "10px" }}>Quiz de Capitales de Europa</h1>

      <p style={{ fontSize: "20px", marginBottom: "8px" }}>
        Puntos: <strong>{score}</strong>
      </p>

      <p style={{ fontSize: "16px", marginBottom: "8px" }}>
        Modo actual: <strong>{useTextMode ? "Escribir respuesta" : "4 opciones"}</strong>
      </p>

      <p style={{ fontSize: "14px", marginBottom: "18px", color: "#475569" }}>
        Las capitales que fallas se repiten más.
      </p>

      <h2 style={{ marginBottom: "20px" }}>
        ¿Cuál es la capital de{" "}
        <span style={{ color: "#ea580c" }}>{current.country}</span>?
      </h2>

      {!useTextMode ? (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(2, minmax(140px, 220px))",
            gap: "12px",
            justifyContent: "center",
            marginBottom: "20px"
          }}
        >
          {shuffledOptions.map((option) => (
            <button
              key={option}
              onClick={() => handleOptionClick(option)}
              style={{
                padding: "14px",
                fontSize: "16px",
                borderRadius: "10px",
                border: "1px solid #cbd5e1",
                background: "white",
                cursor: "pointer",
                boxShadow: "0 2px 8px rgba(0,0,0,0.06)"
              }}
            >
              {option}
            </button>
          ))}
        </div>
      ) : (
        <div style={{ marginBottom: "20px" }}>
          <input
            type="text"
            value={textAnswer}
            onChange={(e) => setTextAnswer(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleTextSubmit();
            }}
            placeholder="Escribe la capital"
            style={{
              padding: "12px",
              fontSize: "16px",
              width: "260px",
              maxWidth: "80%",
              borderRadius: "8px",
              border: "1px solid #cbd5e1",
              marginRight: "10px"
            }}
          />

          <button
            onClick={handleTextSubmit}
            style={{
              padding: "12px 18px",
              fontSize: "16px",
              cursor: "pointer",
              borderRadius: "8px",
              border: "none",
              background: "#2563eb",
              color: "white"
            }}
          >
            Comprobar
          </button>
        </div>
      )}

      <p style={{ minHeight: "24px", fontWeight: "bold", marginBottom: "24px" }}>
        {message}
      </p>

      <div style={{ marginTop: "24px" }}>
        <EuropeMap highlightedCountry={current.countryMap} />
      </div>
    </div>
  );
}