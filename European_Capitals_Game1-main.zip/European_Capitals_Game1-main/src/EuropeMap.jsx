import { useEffect, useState } from "react";
import {
  ComposableMap,
  Geographies,
  Geography
} from "@vnedyalk0v/react19-simple-maps";

export default function EuropeMap({ highlightedCountry }) {
  const geoUrl = "/europe-full.geojson";
  const [status, setStatus] = useState("loading");
  const [geoData, setGeoData] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch(geoUrl)
      .then((res) => {
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }
        return res.json();
      })
      .then((data) => {
        setGeoData(data);
        setStatus("ok");
      })
      .catch((err) => {
        console.error("ERROR GEOJSON:", err);
        setError(String(err));
        setStatus("error");
      });
  }, []);

  if (status === "loading") {
    return (
      <div
        style={{
          width: "100%",
          maxWidth: "1100px",
          height: "700px",
          margin: "0 auto",
          background: "#e2e8f0",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "28px",
          borderRadius: "12px"
        }}
      >
        Cargando mapa completo...
      </div>
    );
  }

  if (status === "error") {
    return (
      <div
        style={{
          width: "100%",
          maxWidth: "1100px",
          minHeight: "250px",
          margin: "0 auto",
          background: "#fee2e2",
          color: "#991b1b",
          padding: "20px",
          borderRadius: "12px",
          textAlign: "left"
        }}
      >
        <h2>Error cargando el mapa</h2>
        <p><strong>Archivo:</strong> {geoUrl}</p>
        <p><strong>Error:</strong> {error}</p>
      </div>
    );
  }

  return (
    <div style={{ width: "100%", display: "flex", justifyContent: "center" }}>
      <ComposableMap
        projection="geoMercator"
        projectionConfig={{
          center: [18, 54],
          scale: 380
        }}
        width={1100}
        height={750}
        style={{
          width: "100%",
          maxWidth: "1100px",
          height: "auto",
          background: "#f8fafc",
          borderRadius: "12px"
        }}
      >
        <Geographies geography={geoData}>
          {({ geographies }) =>
            geographies.map((geo) => {
              const mapName =
                geo.properties.NAME ||
                geo.properties.name ||
                geo.properties.ADMIN ||
                geo.properties.NAME_EN ||
                geo.properties.SOVEREIGNT ||
                "";

              const isHighlighted =
                highlightedCountry &&
                mapName.toLowerCase() === highlightedCountry.toLowerCase();

              return (
                <Geography
                  key={geo.rsmKey}
                  geography={geo}
                  fill={isHighlighted ? "#f97316" : "#cbd5e1"}
                  stroke="#ffffff"
                  strokeWidth={0.6}
                  style={{
                    default: { outline: "none" },
                    hover: { fill: "#93c5fd", outline: "none" },
                    pressed: { outline: "none" }
                  }}
                />
              );
            })
          }
        </Geographies>
      </ComposableMap>
    </div>
  );
}